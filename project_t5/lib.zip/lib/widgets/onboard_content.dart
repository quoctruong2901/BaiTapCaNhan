import 'package:flutter/material.dart';
import '../models/onboard_page.dart';

class OnboardContent extends StatelessWidget {
  final OnboardPage page;
  final VoidCallback? onNext;
  final VoidCallback? onBack;
  final bool isLast;

  const OnboardContent({
    super.key,
    required this.page,
    this.onNext,
    this.onBack,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(page.image, height: 250),
          const SizedBox(height: 30),
          Text(
            page.title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            page.description,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, color: Colors.black54),
          ),
          const SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (onBack != null)
                ElevatedButton.icon(
                  onPressed: onBack,
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Back'),
                )
              else
                const SizedBox(width: 80),
              ElevatedButton.icon(
                onPressed: onNext,
                icon: Icon(isLast ? Icons.check : Icons.arrow_forward),
                label: Text(page.buttonText),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
